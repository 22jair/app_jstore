//
//  PostListViewController.swift
//  JStore
//
//  Created by user190858 on 7/19/21.
//

import UIKit
class PostLisViewController: UIViewController{
    
 
}
