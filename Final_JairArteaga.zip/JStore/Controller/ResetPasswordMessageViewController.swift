//
//  ResetPasswordMessageViewController.swift
//  JStore
//
//  Created by JairArteaga on 5/26/21.
//


import UIKit

class ResetPasswordMessageViewController: UIViewController {
    
}
