//
//  CustomUIButton.swift
//  JStore
//
//  Created by Jair Arteaga on 5/26/21.
//

import UIKit

class CustomUIButton: UIButton {

    
    
}
